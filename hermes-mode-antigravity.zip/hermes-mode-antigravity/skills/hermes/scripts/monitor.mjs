import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const PORT = process.env.PORT || 4567;
const hermesDir = path.join(process.cwd(), '.hermes');
const chatterJsonl = path.join(hermesDir, 'chatter.jsonl');

function getMessages() {
  if (!fs.existsSync(chatterJsonl)) return [];
  try {
    const lines = fs.readFileSync(chatterJsonl, 'utf-8').split('\n').filter(Boolean);
    return lines.map(line => {
      try { return JSON.parse(line); } catch { return null; }
    }).filter(Boolean);
  } catch {
    return [];
  }
}

const server = http.createServer((req, res) => {
  if (req.url === '/api/hermes/chatter') {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*'
    });
    return res.end(JSON.stringify({ messages: getMessages() }));
  }

  const html = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Hermes Fleet Monitor</title>
  <style>
    :root {
      --bg: #090d16;
      --card: #111827;
      --border: #1f2937;
      --primary: #38bdf8;
      --accent: #818cf8;
      --success: #34d399;
      --text: #f3f4f6;
      --muted: #9ca3af;
    }
    body {
      margin: 0; padding: 24px;
      background: var(--bg); color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .header {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border);
    }
    .title-group { display: flex; align-items: center; gap: 14px; }
    .logo {
      width: 42px; height: 42px; background: linear-gradient(135deg, #38bdf8, #818cf8);
      border-radius: 10px; display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 20px; color: #fff;
    }
    h1 { margin: 0; font-size: 22px; }
    .badge {
      background: rgba(56, 189, 248, 0.1); border: 1px solid var(--primary);
      color: var(--primary); padding: 4px 10px; border-radius: 9999px;
      font-size: 12px; font-weight: 600;
    }
    .grid { display: grid; grid-template-columns: 320px 1fr; gap: 24px; }
    .panel { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; }
    .panel h2 {
      margin-top: 0; font-size: 15px; font-weight: 600; border-bottom: 1px solid var(--border);
      padding-bottom: 10px; margin-bottom: 14px; color: var(--muted); text-transform: uppercase;
    }
    .worker-card {
      background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border);
      border-radius: 8px; padding: 12px; margin-bottom: 10px;
    }
    .worker-name { font-weight: 600; color: var(--primary); font-size: 14px; }
    .worker-role { font-size: 12px; color: var(--muted); margin-top: 2px; }
    .chat-container { display: flex; flex-direction: column; gap: 10px; max-height: 72vh; overflow-y: auto; }
    .chat-msg {
      background: rgba(255, 255, 255, 0.03); border-left: 3px solid var(--primary);
      border-radius: 0 8px 8px 0; padding: 10px 14px; font-size: 14px; line-height: 1.5;
    }
    .chat-msg.system { border-left-color: var(--accent); }
    .chat-msg.task { border-left-color: var(--success); }
    .msg-meta { display: flex; gap: 8px; font-size: 12px; color: var(--muted); margin-bottom: 4px; }
    .sender { font-weight: 600; color: #fff; }
    .target { color: var(--primary); }
    .empty { color: var(--muted); font-style: italic; text-align: center; padding: 40px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="title-group">
      <div class="logo">H</div>
      <div>
        <h1>Hermes Fleet Monitor</h1>
        <div style="font-size: 12px; color: var(--muted);">Multi-Agent Orchestration & Chatter Live Stream</div>
      </div>
    </div>
    <div class="badge">● LIVE SYNC</div>
  </div>
  <div class="grid">
    <div class="panel">
      <h2>Hermes Workers</h2>
      <div class="worker-card"><div class="worker-name">👑 lead (Оркестратор)</div><div class="worker-role">Архитектура, задачи и координация</div></div>
      <div class="worker-card"><div class="worker-name">💻 dmitry</div><div class="worker-role">Multi-Stack Backend (Clean Arch, API, Outbox, Concurrency, .NET/Py/Node/Go)</div></div>
      <div class="worker-card"><div class="worker-name">🎨 elena</div><div class="worker-role">Frontend & UI/UX (Компоненты, реактивность)</div></div>
      <div class="worker-card"><div class="worker-name">🛡️ viktor</div><div class="worker-role">Lead QA & AppSec (7-векторный QA, TDD, OWASP/Auth/Cloudflare, DevSecOps)</div></div>
      <div class="worker-card"><div class="worker-name">⚙️ alexey</div><div class="worker-role">DevOps & Protocols (Оборудование, сокеты, шины)</div></div>
      <div class="worker-card"><div class="worker-name">📊 ruslan</div><div class="worker-role">SAP & Enterprise (NCo, BAPI, GUI Scripting, IDoc, OData)</div></div>
      <div class="worker-card"><div class="worker-name">🔍 artem</div><div class="worker-role">Reverse Engineering (CIL, бинарные протоколы)</div></div>
      <div class="worker-card"><div class="worker-name">🧠 mikhail</div><div class="worker-role">AI/ML & LLM Architect (Hybrid RAG, Context/Memory, Fine-Tuning/vLLM, Red-Team)</div></div>
      <div class="worker-card"><div class="worker-name">🧹 sergey</div><div class="worker-role">Refactoring Architect (CRAP-Score, Characterization, Strangler Fig, SOLID)</div></div>
      <div class="worker-card"><div class="worker-name">🏭 igor</div><div class="worker-role">Hardware Mock & Simulator (Stateful FSM, Fault Injection, CRC Fuzzing)</div></div>
      <div class="worker-card"><div class="worker-name">📝 anna</div><div class="worker-role">System Documenter (C4/Mermaid, Diátaxis, ADR, OpenAPI, Runbooks)</div></div>
      <div class="worker-card"><div class="worker-name">🗄️ denis</div><div class="worker-role">Multi-Engine High-Load DBA (SQLite, Postgres, MSSQL, MySQL, Redis/OLAP)</div></div>
      <div class="worker-card"><div class="worker-name">⚖️ stanislav</div><div class="worker-role">Chief Fleet Auditor (Ревизор правил и комплаенса)</div></div>
    </div>
    <div class="panel">
      <h2>Inter-Agent Chatter Feed (<span id="count">0</span>)</h2>
      <div class="chat-container" id="chat-feed">
        <div class="empty">Ожидание сообщений агентов...</div>
      </div>
    </div>
  </div>
  <script>
    async function refresh() {
      try {
        const res = await fetch('/api/hermes/chatter');
        const data = await res.json();
        if (!data || !data.messages) return;
        document.getElementById('count').textContent = data.messages.length;
        const feed = document.getElementById('chat-feed');
        if (data.messages.length === 0) {
          feed.innerHTML = '<div class="empty">Сообщений пока нет. Они появятся здесь при работе агентов.</div>';
          return;
        }
        feed.innerHTML = data.messages.map(m => \`
          <div class="chat-msg \${m.kind || ''}">
            <div class="msg-meta">
              <span>\${m.timeFormatted || ''}</span>
              <span class="sender">\${m.sender}</span>
              <span>➔</span>
              <span class="target">\${m.target}</span>
            </div>
            <div>\${m.content}</div>
          </div>
        \`).join('');
      } catch (err) {}
    }
    setInterval(refresh, 2000);
    refresh();
  </script>
</body>
</html>`;

  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(html);
});

server.listen(PORT, () => {
  console.log(`[Hermes Monitor] Запущен на http://localhost:${PORT}`);
});
